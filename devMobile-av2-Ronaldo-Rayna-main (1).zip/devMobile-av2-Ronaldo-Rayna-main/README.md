# devMobile-av2-Ronaldo-Rayna

O projeto é uma lista de tarefas estilo ToDo

Alunos:

Ronaldo Guimarães,
Rayná Araujo
